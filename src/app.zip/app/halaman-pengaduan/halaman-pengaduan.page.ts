import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-halaman-pengaduan',
  templateUrl: './halaman-pengaduan.page.html',
  styleUrls: ['./halaman-pengaduan.page.scss'],
  standalone:false
})
export class HalamanPengaduanPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
